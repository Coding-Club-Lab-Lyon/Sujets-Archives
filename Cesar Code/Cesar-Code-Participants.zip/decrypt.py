import sys

def decrypt(): #à completer
