import sys

# encrypt function
def decrypt(text,step):
    # define variable to hold the result
    result = ""

    # get character by character in text
    for i in range(len(text)):
        char = text[i]
        # If the character is not an alphabetic not encrypt
        if not char.isalpha():
            result += char
        # If the character is an uppercase character
        elif char.isupper():
            result += chr((ord(char) + step-65) % 26 + 65) # do the encryption
        # If the character is a lowercase character
        else:
            result += chr((ord(char) + step - 97) % 26 + 97) # do the encryption
    # return the result
    return result

# try to open the given file
try:
    f = open(sys.argv[1], 'r') # open the file for read
    f1 = open("message-dechiffre.txt", 'w') # open file for write
    # get step size from the user
    step = int(input("Entrez le nombre de décalage des lettres : "))
    # read whole data in the given file to text variable
    text = f.read()
    # write the decrypted data to message-dechiffre.txt file
    f1.write(decrypt(text, 26-step))
    # close the opened files
    f.close()
    f1.close()
    print("Le fichier chiffré est disponible sous le nom message-dechiffre.txt")

# If the given file is not exist
except Exception:
    print("Le fichier est pas existant.")


