<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel='stylesheet' href='style2.css'>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Abel&display=swap" rel="stylesheet">
    <title>Glace</title>

</head>
<body>

<div class="wrapper fadeInDown">
    <div id="formContent">
        <form action="/spirit" method="post">
            <input type="number" id="angle" class="fadeIn second" name="angle" placeholder="Angle de frappe">
            <input type="number" id="force" class="fadeIn third" name="force" placeholder="Force de frappe">
            <input type="submit" class="fadeIn fourth" value="Tape">
        </form>

    </div>
</div>
</body>