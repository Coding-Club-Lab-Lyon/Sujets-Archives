<?php
    $curl = curl_init();
    $result = "Votre piolet glisse sur la glace";
    $f = 1;
    $i = 1;
    while(($f <= 10) && ($result == "Votre piolet glisse sur la glace")){
        while(($i <= 180) && ($result == "Votre piolet glisse sur la glace")){
            $data = array("angle" => $i, "force" => $f);
            $data_encoded = json_encode($data);

            curl_setopt($curl, CURLOPT_URL, "http://api.codingclub.epitech.eu:3000/spirit");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data_encoded);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

            $result = curl_exec($curl);
            if ($result == "Votre piolet glisse sur la glace"){
                $i++;
            }
        }
        if ($result == "Votre piolet glisse sur la glace"){
            $f++;
            $i = 0;
        }
    }

    if ($result != "Votre piolet glisse sur la glace"){
        echo "<h2>Angle = " . $i . "</h2>";
        echo "<h2>Force = " . $f . "</h2>";
        echo "<h2>" . $result . "</h2>";
    }

    curl_close($curl);

?>