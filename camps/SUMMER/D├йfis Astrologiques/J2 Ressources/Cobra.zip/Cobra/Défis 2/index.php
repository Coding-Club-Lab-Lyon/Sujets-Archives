<?php

try {
    $bdd = new PDO('mysql:host=localhost;dbname=poeme;charset=utf8', 'root', 'root');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}


// On récupère tout le contenu de la table



$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "DELETE FROM memoires WHERE details='+'";
$req = $bdd->prepare($sql);
$req->execute();

$reponse = $bdd->query('SELECT * FROM memoires WHERE w_index%4 != 0 ORDER BY order_num DESC');

// On affiche chaque entrée une à une
while ($donnees = $reponse->fetch())
{
    ?>
    <p>
        <?php echo $donnees['word']; ?>
        <?php echo $donnees['w_index']; ?>
        <?php echo $donnees['details']; ?>
    </p>
    <?php
}


$reponse->closeCursor(); // Termine le traitement de la requête

?>