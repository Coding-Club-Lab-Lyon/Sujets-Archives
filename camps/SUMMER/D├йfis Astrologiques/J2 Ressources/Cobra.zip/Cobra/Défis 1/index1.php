<?php
$image = imagecreate(1000, 1000);
$etoile = imagecreatefrompng("etoile.png");

$background_color = imagecolorallocate($image, 50, 100, 255);
$line_color = imagecolorallocate($image, 255, 255, 255);

$values = array(
    50,  200,
    60, 300,
    55, 320,
    20,  400,
    170, 420
);

imageline($image, $values[0], $values[1], $values[2], $values[3], $line_color);
imageline($image, $values[2], $values[3], $values[4], $values[5], $line_color);
imageline($image, $values[4], $values[5], $values[6], $values[7], $line_color);
imageline($image, $values[4], $values[5], $values[8], $values[9], $line_color);

imagecopymerge_alpha($image, $etoile, $values[0] - 15, $values[1] - 15, 0, 0, imagesx($etoile), imagesy($etoile), 100);
imagecopymerge_alpha($image, $etoile, $values[2] - 15, $values[3] - 15, 0, 0, imagesx($etoile), imagesy($etoile), 100);
imagecopymerge_alpha($image, $etoile, $values[4] - 15, $values[5] - 15, 0, 0, imagesx($etoile), imagesy($etoile), 100);
imagecopymerge_alpha($image, $etoile, $values[6] - 15, $values[7] - 15, 0, 0, imagesx($etoile), imagesy($etoile), 100);
imagecopymerge_alpha($image, $etoile, $values[8] - 15, $values[9] - 15, 0, 0, imagesx($etoile), imagesy($etoile), 100);

header("Content-type:image/png");
imagepng($image);
imagedestroy($image);

function imagecopymerge_alpha($dst_im, $src_im, $dst_x, $dst_y, $src_x, $src_y, $src_w, $src_h, $pct){
    // creating a cut resource
    $cut = imagecreatetruecolor($src_w, $src_h);

    // copying relevant section from background to the cut resource
    imagecopy($cut, $dst_im, 0, 0, $dst_x, $dst_y, $src_w, $src_h);

    // copying relevant section from watermark to the cut resource
    imagecopy($cut, $src_im, 0, 0, $src_x, $src_y, $src_w, $src_h);

    // insert cut resource to destination image
    imagecopymerge($dst_im, $cut, $dst_x, $dst_y, 0, 0, $src_w, $src_h, $pct);
}
?>