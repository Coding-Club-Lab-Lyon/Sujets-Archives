<?php
    $curl = curl_init(); //Creation d'une instance de Curl

    //Ajout des options de la requete pour curl
    curl_setopt($curl, CURLOPT_URL, "http://api.codingclub.epitech.eu:3000/fish");// Cette fois on récupere tous les poissons
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $fishs = curl_exec($curl); //Envoi de la requete et stockage de la réponse de l'api dans fishs
    $fishs = json_decode($fishs); // on créer un objet JSON a partir de la réponse de l'api

    curl_setopt($curl, CURLOPT_URL, "http://api.codingclub.epitech.eu:3000/fish/11");// Cette fois on récupere le poisson manquant
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    $lostfish = curl_exec($curl); //Envoi de la requete et stockage de la réponse de l'api dans lostfish
    $lostfish = json_decode($lostfish);

    $data = array("say" => "Suis les vibrations pour retrouver ton chemin");//On créer un tableau key => value
    $data_encoded = json_encode($data);// On encode le tableau en json

    curl_setopt($curl, CURLOPT_URL, "http://api.codingclub.epitech.eu:3000/fish");// Cette fois on récupere le poisson manquant
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POST, 1); // On paremetre la requete comme une requete post
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_encoded);// On ajoute a la requete les données 
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));// On indique le type de données qu'on envoie

    $lastfish = curl_exec($curl);
    $lastfish = json_decode($lastfish);

    curl_close($curl);// Fermeture de la session curl

?>

<!-- Cette fois on leur donne l'html tout en leur expliquant le foreach-->

<!DOCTYPE html>
<link rel='stylesheet' href='style.css'>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
<body>
    <?php foreach ($fishs as &$fish) : ?>
        <div>
            <h2><?php echo $fish->name?></h2>
            <img src=<?php echo $fish->picture?>/>
        </div>
    <?php endforeach; ?>
    <div>
        <h2><?php echo $lostfish->name?></h2>
        <img src=<?php echo $lostfish->picture?>/>
    </div>
    <div>
        <h2><?php echo $lastfish->name?></h2>
        <img src=<?php echo $lastfish->picture?>/>
    </div>
</body>