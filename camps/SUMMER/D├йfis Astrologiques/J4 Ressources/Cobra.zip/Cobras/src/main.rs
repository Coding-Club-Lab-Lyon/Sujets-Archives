use rand::Rng;
use help::GameState;
use help::Element;
use help::DoubleArray;
use help::update_board;
use help::print_board;
use help::get_input;
use help::parse_input;
use help::parse_second_input;

mod help;

fn generate_board(size: usize) -> DoubleArray {
    let mut board = vec![vec![Element::Clear; size]; size];
    let mut nb_cactus = 0;

    for _ in 0..size {
        let x = rand::thread_rng().gen_range(0..size);
        let y = rand::thread_rng().gen_range(0..size);

        board[x][y] = Element::Cactus;
    }

    for ay in 0..size {
        for ax in 0..size {
            if board[ax][ay] == Element::Clear {
                if ax < size - 1 && board[ax + 1][ay] == Element::Cactus {nb_cactus += 1;}
                if ax > 0 && board[ax - 1][ay] == Element::Cactus {nb_cactus += 1;}
                if ay < size - 1 && board[ax][ay + 1] == Element::Cactus {nb_cactus += 1;}
                if ay > 0 && board[ax][ay - 1] == Element::Cactus {nb_cactus += 1;}
                if ax < size - 1 && ay < 2 && board[ax + 1][ay + 1] == Element::Cactus {nb_cactus += 1;}
                if ax < size - 1 && ay > 0 && board[ax + 1][ay - 1] == Element::Cactus {nb_cactus += 1;}
                if ax > 0 && ay < 2 && board[ax - 1][ay + 1] == Element::Cactus {nb_cactus += 1;}
                if ax > 0 && ay > 0 && board[ax - 1][ay - 1] == Element::Cactus {nb_cactus += 1;}
                if nb_cactus > 0 { board[ax][ay] = Element::Number(nb_cactus);}
            }
            nb_cactus = 0;
        }
    }

    return board;
}

pub fn lose(board: &DoubleArray, coords: &Vec<usize>) -> bool {
    if board[coords[0]][coords[1]] == Element::Cactus {
        return true;
    }

    return false;
}

pub fn get_cactus_number(board_solution: &DoubleArray) -> u16 {
    let mut cactus_in_solution = 0;

    for ay in 0..board_solution.len() {
        for ax in 0..board_solution.len() {
            if board_solution[ax][ay] == Element::Cactus {
                cactus_in_solution += 1;
            }
        }
    }

    return cactus_in_solution;
}

pub fn win(board: &DoubleArray, board_solution: &DoubleArray, cactus_number: u16) -> bool {
    let mut found_cactus = 0;

    for ay in 0..board.len() {
        for ax in 0..board.len() {
            if board[ax][ay] == Element::Horne && board_solution[ax][ay] == Element::Cactus {
                found_cactus += 1;
            }
        }
    }

    if found_cactus == cactus_number {
        return true;
    }

    return false;
}

pub fn main() {
    let size = 4;
    let mut state = GameState::Playing;
    let mut board = vec![vec![Element::Unknown; size]; size];
    let board_solution = generate_board(size as usize);
    let cactus_number = get_cactus_number(&board_solution);
    let mut horns_remaining = cactus_number;

    print_board(&board_solution);

    println!("");

    print_board(&board);

    while state == GameState::Playing {
        let input_coords = get_input("Entrez les coordonnées sous la forme : X Y");
        let coords = parse_input(input_coords);

        let text = format!("Tapez 'v' pour vérifier la case ou 'c' pour y ajouter une corne : {} corne(s) restante(s)", horns_remaining);

        let input_action = get_input(&text);
        let action = parse_second_input(input_action);

        board = update_board(board, &board_solution, &coords, &action.unwrap(), &mut horns_remaining);

        print_board(&board);

        if lose(&board, &coords) == true {
            state = GameState::Lose;
        } else if win(&board, &board_solution, cactus_number) == true {
            state = GameState::Win;
        }
    }

    match state {
        GameState::Win => println!("Bien joué ! Vous avez gagné !"),
        GameState::Lose => println!("Pas de chance ! Vous avez perdu ."),
        _ => {}
    }

    return;
}
