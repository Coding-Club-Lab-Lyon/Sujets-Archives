#![allow(unused)]
#![allow(dead_code)]
use rand::Rng;
use help::GameState;
use help::Element;
use help::DoubleArray;
use help::update_board;
use help::print_board;
use help::get_input;
use help::parse_input;
use help::parse_second_input;

mod help;

fn generate_board(size: usize) -> DoubleArray {
    let mut board = vec![vec![Element::Clear; size]; size];
    let mut nb_cactus = 0;

    for _ in 0..size {
        let x = rand::thread_rng().gen_range(0..size);
        let y = rand::thread_rng().gen_range(0..size);

        board[x][y] = Element::Cactus;
    }
    return board;
}
pub fn lose(board: &DoubleArray, coords: &Vec<usize>) -> bool {
    unimplemented!();
}

pub fn get_cactus_number(board_solution: &DoubleArray) -> u16 {
    let mut cactus_in_solution = 0;

    for ay in 0..board_solution.len() {
        for ax in 0..board_solution.len() {
            if board_solution[ax][ay] == Element::Cactus {
                cactus_in_solution += 1;
            }
        }
    }

    return cactus_in_solution;
}

pub fn win(board: &DoubleArray, board_solution: &DoubleArray, cactus_number: u16) -> bool {
    unimplemented!();
}

pub fn main() {
    let size = 4;
    let mut state = GameState::Playing;
    let mut board = vec![vec![Element::Unknown; size]; size];
    let board_solution = generate_board(size as usize);
    let cactus_number = get_cactus_number(&board_solution);
    let mut horns_remaining = cactus_number;

    print_board(&board_solution);
    println!("");
    print_board(&board);

    return;
}
