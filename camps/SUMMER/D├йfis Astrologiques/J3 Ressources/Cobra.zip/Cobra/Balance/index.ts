// récupération des éléments HTML en TypeScript pour pouvoir les utiliser
const startButton = document.getElementById("start-game");
const infoText = document.getElementById('info-text');
const scoreText = document.getElementById("score");

const map = document.getElementById("map");
const balanceBar = <HTMLProgressElement>document.getElementById("balance-bar");

// Déclaration d'une énumération Direction pour faciliter le code
// Elle permettra de dire où le snake doit aller
enum Direction {
  up,
  down,
  left,
  right
}

const MAP_SIZE: number = 16; // La taille de la map
let playerMove: boolean = false; // Savoir si le joueur a demandé une direction pendant la frame. Elle vaut "false" si le joueur n'a pas changé de direction, sinon elle vaut "true"
let snakeEat: boolean = false; // Savoir si le serpent a mangé pendant la frame. Vaut "true" si c'est le cas, sinon "false"
let snake: any = []; // Stock le serpent et ces informations
let foods: any = []; // Stock toutes les nourritures de la map
let clock: number; // Stock la variable gérant les frames du jeu
let score: number; // Stock le score du joueur lui permettant de gagner

// Initialise les éléments en début de jeu
function initializeGameElements(): void {
  snake = [{"type": "head", "position": [3, 1], "direction": Direction.right},
          {"type": "basic", "position": [2, 1], "direction": Direction.right},
          {"type": "basic", "position": [1, 1], "direction": Direction.right}];
  foods = [];
  balanceBar.value = 50;
  score = 0;
  clock = setInterval(moveSnake, 250);
}

// Appelé lorsque le joueur lance la partie
function startGame(): void {
  initializeGameElements();
  hideTextAndButton();
  addFood("banana");
  addFood("cucumber");
  addFood("burger");
  addFood("tenders");
  drawSnake();
  drawFood();
}

// Cache le bouton pour lancer la partie et le texte informatif s'il y a
function hideTextAndButton(): void {
  if (!infoText.classList.contains('hidden'))
    infoText.classList.add('hidden');
  startButton.classList.add('hidden');
  scoreText.innerHTML = "Score : 0";
}

// Dessine le serpent sur la page web
function drawSnake(): void {
  snake.forEach(body => {
    const new_div = document.createElement("div");
    new_div.style.gridRowStart = body.position[1];
    new_div.style.gridColumnStart = body.position[0];
    new_div.classList.add(body.type);
    map.appendChild(new_div);
  });
}

// Dessine la nourriture sur la page web
function drawFood(): void {
  foods.forEach(food => {
    const new_div = document.createElement("div");
    new_div.style.gridRowStart = food.position[1];
    new_div.style.gridColumnStart = food.position[0];
    new_div.classList.add("food");
    new_div.classList.add(food.type);
    map.appendChild(new_div);
  });
}

// Contrôle le changement de direction demandé par le joueur
// La variable "direction" correspond à la direction demandée par le joueur
function changeDirection(direction): void {
  if (playerMove === false) {
    if (direction === Direction.up && snake[0].direction !== Direction.down && snake[0].direction !== Direction.up) {
      snake[0].direction = direction;
      playerMove = true;
    }
    else if (direction === Direction.left && snake[0].direction !== Direction.right && snake[0].direction !== Direction.left) {
      snake[0].direction = direction;
      playerMove = true;
    }
    else if (direction === Direction.right && snake[0].direction !== Direction.left && snake[0].direction !== Direction.right) {
      snake[0].direction = direction;
      playerMove = true;
    }
    else if (direction === Direction.down && snake[0].direction !== Direction.up && snake[0].direction !== Direction.down) {
      snake[0].direction = direction;
      playerMove = true;
    }
  }
}

// Vérifie que la case voulue n'est pas déjà occupé. Elle retourne "true" si la case est vide, sinon elle renvoie "false"
// Les variables "x" et "y" sont les positions de la map à vérifier
function checkEmptyCase(x, y): boolean {
  let status: boolean = true;

  snake.forEach(body => {
    if (x === body.position[0] && y === body.position[1]) {
       status = false
    }
  });
  foods.forEach(food => {
    if (x === food.position[0] && y === food.position[1]) {
       status = false
    }
  });
  return status;
}

// Trouve une case vide dans la map
// La variable "type" correspond au type de nourriture
function findEmptyPlace(type: string): void {
  for (let i = 0; i <= MAP_SIZE; i++)
    for (let j = 0; j <= MAP_SIZE; j++)
      if (checkEmptyCase(i, j) === true) {
        placeFood(type, i, j);
        return;
      }
}

// Ajoute la nourriture à la map
function placeFood(type: string, x: number, y: number): void {
  foods.push({"type": type, "position": [x, y]});
}

// Augmente la taille du serpent
// La variable "type" est le type de nourriture
function addSnakePart(type: string): void {
  snake.push({"type": type, "position": snake[snake.length - 1].position, "direction": snake[snake.length - 1].direction});
}

// Actualise l'affichage du score
// La variable "amount" correspond au montant à ajouter au score actuel
function scoreUpdate(amount: number): void {
  score += amount;
  scoreText.innerHTML = "Score : " + String(score);
}

// Mets à jour la barre d'équilibre en fonction du type de nourriture mangé
// La variable "type" indique le type de nourriture
function updateBalanceBarAndScore(type: string): void {
  if (type === "banana") {
    balanceBar.value -= 10;
    scoreUpdate(10);
  }
  else if (type === "cucumber") {
    balanceBar.value -= 30;
    scoreUpdate(30);
  }
  else if (type === "burger") {
    balanceBar.value += 25;
    scoreUpdate(25);
  }
  else {
    balanceBar.value += 15;
    scoreUpdate(15);
  }
}

// Mets à jour la barre d'équilibre en fonction du type de nourriture mangé
// La variable "food" correspond à la nourriture mangée et la variable "index" est la position de la nourriture dans le tableau content toutes les nourritures
function updateFoodOnMap(food: any, index: number): void {
  addSnakePart(food.type);
  snakeEat = true;
  foods.splice(index, 1);
  addFood(food.type);
  updateBalanceBarAndScore(food.type);
}

// Vérifie si la tête du serpent est entrée en collision avec son corps et retourne "true" dans ce cas, sinon elle renvoie "false"
function checkBodyCollision(): boolean {
  let borderCollision: boolean = false;

  snake.forEach(body => {
    if (body.type !== "head" && snake[0].position[0] === body.position[0] && snake[0].position[1] === body.position[1]) {
      borderCollision = true;
    }
  });
  return borderCollision;
}

// Ferme le jeu, réaffiche le bouton pour lancer le jeu et supprimes le serpent et la nourriture
// La variable "status" vaut "true" si le joueur à gagner et "false" si le joueur a perdu
function closeGame(status: boolean): void {
  map.textContent = '';
  startButton.classList.remove('hidden');
  infoText.classList.remove('hidden');
  clearInterval(clock);

  if (status === true) {
    infoText.innerHTML = "Vous avez gagné";
    startButton.firstChild.textContent = "Relancer";
  }
  else {
    infoText.innerHTML = "Vous avez perdu";
    startButton.firstChild.textContent = "Réessayer";
  }
}

// Appelé à chaque frame, fait bouger le snake en fonction des actions effectuées
function moveSnake(): void {
  playerMove = false;
  let previous_body: any = snake[0];

  map.textContent = '';
  for (let i = snake.length - 1; i >= 0; i--) {
    if (snake[i].type === "head") {
      if (snake[i].direction === Direction.up)
        snake[i].position = [snake[i].position[0], snake[i].position[1] - 1]
      else if (snake[i].direction === Direction.down)
        snake[i].position = [snake[i].position[0], snake[i].position[1] + 1];
      else if (snake[i].direction === Direction.left)
        snake[i].position = [snake[i].position[0] - 1, snake[i].position[1]]
      else
        snake[i].position = [snake[i].position[0] + 1, snake[i].position[1]];
    }
    else if (snakeEat === false) {
      snake[i].direction = snake[i - 1].direction;
      snake[i].position = snake[i - 1].position;
    }
    else {
      snakeEat = false;
    }
  }
  drawSnake();
  foods.forEach((food, index) => {
    checkSnakeEatFood(food, index);
  });
  drawFood();
  checkGameOver();
}

// Ajoute un détecteur sur les touches du clavier. Si une des touches directionnelles est appuyée, cela exécutera une action.
document.addEventListener('keydown', (event) => buttonPressed(event));

// Ajoute un détecteur au bouton pour lancer le jeu afin de savoir quand le joueur appuie dessus
startButton.addEventListener('click', () => startGame());
