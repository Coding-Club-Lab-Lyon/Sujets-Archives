// Appelée lorsqu'une touche du clavier est appuyée
// La variable "event" regroupe beaucoup de donnée mais "event.key" indique le nom de la touche appuyée
function buttonPressed(event: any): void {
  switch (event.key) {
    case "ArrowDown":
      changeDirection(Direction.down);
      break;
    case "ArrowUp":
      changeDirection(Direction.up);
      break;
    case "ArrowLeft":
      changeDirection(Direction.left);
      break;
    case "ArrowRight":
      changeDirection(Direction.right);
      break;
    default: break;
  }
}

// Trouve une case vide dans la map pour pouvoir y placer de la nourriture
// La variable "type" indique le type de nourriture à placer
function addFood(type: string): void {
  let x: number = 0;
  let y: number = 0;
  let emptyPlaceFound: boolean = false;

  for (let i = 0; i <= 10 && emptyPlaceFound === false; i++) {
    x = Math.floor(Math.random() * MAP_SIZE) + 1;
    y = Math.floor(Math.random() * MAP_SIZE) + 1;
    emptyPlaceFound = checkEmptyCase(x, y);
  }

  if (emptyPlaceFound === false)
    findEmptyPlace(type);
  else
    placeFood(type, x, y);
}

// Savoir si la tête du serpent est sur la même case que de la nourriture
// La variable "food" indique la nourriture et la variable "index" est la position de la nourriture dans le tableau contenant toutes les nourritures
function checkSnakeEatFood(food: any, index: number): void {
  if (food.position[0] === snake[0].position[0] && food.position[1] === snake[0].position[1]) {
    updateFoodOnMap(food, index);
  }
}

// Vérifie si le joueur a perdu ou gagné
function checkGameOver(): void {
  let borderCollision: boolean = false;
  let bodyCollision: boolean = checkBodyCollision();

  if (snake[0].position[0] === 0 || snake[0].position[0] === MAP_SIZE + 1 ||
      snake[0].position[1] === 0 || snake[0].position[1] === MAP_SIZE + 1) {
      borderCollision = true;
  }
  if (borderCollision === true || bodyCollision === true || balanceBar.value <= 0 || balanceBar.value >= 100) {
    if (score >= 300)
      closeGame(true);
    else
      closeGame(false);
  }
}
