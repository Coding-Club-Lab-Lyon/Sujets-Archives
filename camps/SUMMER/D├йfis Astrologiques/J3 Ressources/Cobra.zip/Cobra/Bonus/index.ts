var tCar: number[] = new Array; // variable pour calculer l'interval de temps
var letterByWord: number = 5; // nombre de lettre moyenne par mot
var cps: number = 0; // coups par seconde
var mpm: number = 0; // mots par minute
var totalTime: number = 0; // temps total

// permet l'envoie des mots à l'html
function setDividedWords(dividedWords: string[]) {
    document.getElementById("rd_txt").innerHTML = dividedWords.join("");
    document.getElementById("txt").focus();
    (<HTMLInputElement>document.getElementById("txt")).value = "";
    document.getElementById('resultats').style.display = 'none';
}

// permet de récuperer l'input de l'utilisateur stocké dans l'html
function getValue() : string {
    return (<HTMLInputElement>document.getElementById("txt")).value;
}

// permet de changer la couleur
function setColor(color: string) {
    document.getElementById("txt").style.backgroundColor = color;
}

// calcul et affiche les résultats du joueur
function end() {
    totalTime = tCar[nbCar - 1] - tCar[0];
    let time = formatTime(totalTime);
    calculResult(totalTime);
    displayResult(time, cps, mpm);
}

// met le temps sous un format facile à lire
function formatTime(totalTime: number) : string {
    let min = new Date(totalTime).getMinutes();
    let sec = new Date(totalTime).getSeconds();
    let mil = new Date(totalTime).getMilliseconds();
    mil = Math.round(mil/100);
    let time = min +" min. "+ sec +","+ mil +" s";

    return time;
}

// calcul le cps et mpm
function calculResult(totalTime: number) {
    cps = Math.round(100000 * nbCar / totalTime) / 100;
    mpm = Math.round(cps * 600 / letterByWord) / 10;
}

// affiche les résultats 
function displayResult(time: string, cps: number, mpm: number) {
    document.getElementById('resultats').style.display = 'block';
    document.getElementById('temps').innerHTML = "Temps :  " + time;
    document.getElementById('cps').innerHTML = "Coups par seconde :  " + cps;
    document.getElementById('mpm').innerHTML = "Mots par minute :  " + mpm;
}

// surligne en rouge les erreurs
function curseur(val: string, curseur_err_pos: number)
{
    if (val.length < nbCar) {
        document.getElementById("car"+(val.length+1)).style.backgroundColor = "inherit";
        if (curseurErrBol)
            document.getElementById("car" + curseur_err_pos).style.backgroundColor = "#ff7777";
    }
}
