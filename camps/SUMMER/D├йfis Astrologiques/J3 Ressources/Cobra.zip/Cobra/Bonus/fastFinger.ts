var nbCar = 0;
var curseurErrBol: boolean = false;
var listOfWord: string = ""; 

// fonction permettant d'initialiser le jeu
function setRandomWord() {

    const dico: string[] = JSON.parse(data);
    listOfWord = "";

    for (let i = 0 ; i != 1 ; i++) {
        let randomWord = dico[Math.floor(Math.random() * dico.length)];
        listOfWord += randomWord + " ";
    }
    listOfWord = listOfWord.slice(0, -1)

    var dividedWords: string[] = new Array;
    dividedWords = listOfWord.split("");
    for (var i = 0 ; i < listOfWord.length ; i++) {
        dividedWords[i] = '<span id="car' + (i + 1) + '">' + dividedWords[i] + '</span>';
    }
    nbCar = listOfWord.length;

    setDividedWords(dividedWords);
}

// fonction principal de jeu
function fastFinger() {
    var curseurErrPos = 0;
    var val: string = "";
    val = getValue();

    if (val != listOfWord.substr(0, val.length)) {
        if (curseurErrBol == false) {
            curseurErrPos = val.length;
            curseurErrBol = true;
        }
        setColor("#ffbbbb")
    } else {
        curseurErrBol = false;
        setColor("#f0fff0");
        if (val.length >= nbCar)
            end();
    }
    curseur(val, curseurErrPos);
}

setRandomWord();