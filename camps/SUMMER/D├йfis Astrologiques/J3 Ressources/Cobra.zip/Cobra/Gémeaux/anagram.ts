// Fonction principal pour réaliser un solveur d'anagramme
function anagram(input: string): void {
    input = input.toLowerCase();
    let tmpArray: string[] = input.split('');
    tmpArray = tmpArray.sort();
    let sortedInput:string = tmpArray.join('');
    let dico: string[] = JSON.parse(data);
    let sortedDico:string[] = new Array;

    for (let i = 0; i < dico.length; i++) {
        let tmpArray = dico[i].split('');
        tmpArray = tmpArray.sort();
        sortedDico.push(tmpArray.join(''));
    }

    let id:number = sortedDico.indexOf(sortedInput);

    displayResult(id, input, dico[id]);
}
