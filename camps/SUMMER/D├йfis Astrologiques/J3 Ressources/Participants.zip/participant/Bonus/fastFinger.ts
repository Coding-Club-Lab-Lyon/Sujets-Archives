var nbCar = 0;
var curseurErrBol: boolean = false;
var listOfWord: string = ""; 

// fonction permettant d'initialiser le jeu
function setRandomWord() {

}

// fonction principal de jeu
function fastFinger() {
    var curseurErrPos = 0;
    var val: string = "";
}

setRandomWord();