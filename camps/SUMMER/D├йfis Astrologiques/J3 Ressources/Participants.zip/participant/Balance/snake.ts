// Appelée lorsqu'une touche du clavier est appuyée
// La variable "event" regroupe beaucoup de donnée mais "event.key" indique le nom de la touche appuyée
function buttonPressed(event: any): void {
  switch (event.key) {
    case "":
      break;
    case "":
      break;
    case "":
      break;
    case "":
      break;
    default: break;
  }
}

// Trouve une case vide dans la map pour pouvoir y placer de la nourriture
// La variable "type" indique le type de nourriture à placer
function addFood(type: string): void {
}

// Savoir si la tête du serpent est sur la même case que de la nourriture
// La variable "food" indique la nourriture et la variable "index" est la position de la nourriture dans le tableau contenant toutes les nourritures
function checkSnakeEatFood(food: any, index: number): void {
}

// Vérifie si le joueur a perdu ou gagné
function checkGameOver(): void {
}
