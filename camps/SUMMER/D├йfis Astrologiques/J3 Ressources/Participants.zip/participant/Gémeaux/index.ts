// affiche les resultats
function displayResult(id: number, input: string, word: string) {
    if (id != -1) {
        document.getElementById('Yes').innerHTML = "\"" + input + "\" est un anagramme de \"" + word + "\"";
        document.getElementById('Yes').style.display = 'block';
        document.getElementById('No').style.display = 'none';
    }
    else {
        document.getElementById('No').innerHTML = "\"" + input + "\" n'est pas un anagramme";
        document.getElementById('No').style.display = 'block';
        document.getElementById('Yes').style.display = 'none';
    }
}

// Ce morceaux de code permet au programme de savoir quand la touche Entrée de votre appareil est appuyée pour envoyer le mot au programme
document.getElementById('txt').addEventListener('keydown', (event)=>{
    if (event.key === 'Enter')
        anagram((<HTMLInputElement>document.getElementById('txt')).value)
});