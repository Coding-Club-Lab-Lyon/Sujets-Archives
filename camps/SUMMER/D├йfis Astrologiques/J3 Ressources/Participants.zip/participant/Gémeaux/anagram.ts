// Fonction principal pour réaliser un solveur d'anagramme
function anagram(input: string): void {
    
}
