// Appelé lorsque le bouton pour lancer le jeu est appuyé
function startGame(): void {
}

// Ajout d'une nouvelle couleur aléatoire à la séquence
function addColorToComputerSequence(): void {
}

// Appelé lorsqu'un bouton de couleur est appuyé.
// La variable "color" correspond à la couleur touchée par le joueur. Elle est égale à un nombre entre 0 et 3
function colorButtonPressed(color: Color): void {
}
