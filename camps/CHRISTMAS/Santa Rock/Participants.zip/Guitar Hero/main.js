$("#top").text("Hello world");

function Main() {

}

function LaunchGame(id, tiles) {

}

function InitLine(id, tile) {

}

function Rng(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

function InitTab() {

}

function ChangeColor(id, nb) {

}

function ClearColor(id) {

}

function GameLogic(event) {

}