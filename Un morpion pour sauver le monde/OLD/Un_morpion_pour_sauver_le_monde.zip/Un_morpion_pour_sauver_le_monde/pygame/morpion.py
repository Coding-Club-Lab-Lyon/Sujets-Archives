import pygame, sys, random
from pygame.locals import *
from enum import Enum

class player(Enum):
    player1 = 0
    player2 = 1

def get_box(pos):
    for i in range(3):
        if (pos <= (i * 200) + 200):
            return (i)

def change_player(cur_player):
    if (cur_player == player.player1):
        return player.player2
    return player.player1

def check_is_empty(map, i, j):
    if (map[i][j] == '_'):
        return True
    return False

def place_jeton(map, i, j, current_player):
    if (current_player == player.player1):
        map[i][j] = 'X'
        return map
    map[i][j] = 'O'
    return map

def check_map_full(map):
    for i in range(3):
        for j in range(3):
            if (map[i][j] == '_'):
                return False
    return True

def check_win(map):
    if (map[0][0] != '_' and map[0][0] == map[0][1] and map[0][1] == map[0][2]):
        return check_player_win(map[0][0])
    if (map[1][0] != '_' and map[1][0] == map[1][1] and map[1][1] == map[1][2]):
        return check_player_win(map[1][0])
    if (map[2][0] != '_' and map[2][0] == map[2][1] and map[2][1] == map[2][2]):
        return check_player_win(map[2][0])
    if (map[0][0] != '_' and map[0][0] == map[1][0] and map[1][0] == map[2][0]):
        return check_player_win(map[0][0])
    if (map[0][1] != '_' and map[0][1] == map[1][1] and map[1][1] == map[2][1]):
        return check_player_win(map[0][1])
    if (map[0][2] != '_' and map[0][2] == map[1][2] and map[1][2] == map[2][2]):
        return check_player_win(map[0][2])
    if (map[0][0] != '_' and map[0][0] == map[1][1] and map[1][1] == map[2][2]):
        return check_player_win(map[0][0])
    if (map[0][2] != '_' and map[0][2] == map[1][1] and map[1][1] == map[2][0]):
        return check_player_win(map[0][2])
    return False

def check_player_win(box):
    if box == 'X':
        print("Le joueur 1 a gagné")
    else: 
        print("Le joueur 2 a gagné")
    return True

def draw_all(map):
    window.blit(image, (0, 0))
    for i in range(3):
        for j in range(3):
            if (map[i][j] == "X"):
                window.blit(image2, (i * 200, j * 200))
            if (map[i][j] == "O"):
                window.blit(image3, (i * 200, j * 200))

pygame.init()
window = pygame.display.set_mode((600, 600))
pygame.display.set_caption("Morpion")
image = pygame.image.load("background.jpg").convert_alpha()
image2 = pygame.image.load("croix.png").convert_alpha()
image3 = pygame.image.load("rond.png").convert_alpha()

def main():
    map = [['_', '_', '_'], ['_', '_', '_'], ['_', '_', '_']]
    current_player = player.player1

    while True:
        for event in pygame.event.get(): 
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1,0,0):
                    x,y = pygame.mouse.get_pos()
                    i = get_box(x)
                    j = get_box(y)
                    if (check_is_empty(map, i, j) == True):
                        map = place_jeton(map, i, j, current_player)
                        current_player = change_player(current_player)
                        if (check_win(map) == True or check_map_full(map) == True):
                            pygame.quit()
                            sys.exit()
        draw_all(map)
        pygame.display.flip()

main()